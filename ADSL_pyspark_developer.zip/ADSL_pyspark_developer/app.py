from flask import Flask,render_template,jsonify,url_for,request,flash,redirect
from random import sample
import json
from millify import millify
import os
from datetime import datetime

from bin import intialiser
from bin import scpy_prep_data


# parameters

json_file_name="/Users/sathishkumar/Desktop/code space/ADSL_pyspark_developer/jsons/IPE2.json"

# json_file_name="C:/Users/Pooja/Desktop/ADSL/ADSL_pyspark_developer/ADSL_pyspark_developer/jsons/IPE2.json"



app =Flask(__name__)

@app.route('/')
def index():
    json_file=json_file_name

    json_data = open(json_file)
    data = json.load(json_data)
    maps=data['POWERMART']['REPOSITORY']['FOLDER'][0]['MAPPING']
    maps_li=[]
    for i in range(len(maps)):
        maps_li.append(maps[i]['@NAME'])

    return render_template("index.html",maps_li=maps_li)

##################################################################################################



@app.route('/mapping_select', methods=["GET","POST"])
def mapping_select():
    try:
        job = request.form['select_map']
        print(job)
        return redirect(url_for('leverage',job=job))
    except Exception as e:
        print(e)
        return(e)


@app.route('/leverage/<job>')
def leverage(job):
    # print(job)
    try:
        # json_file=json_file
        # pointer=intialiser.initiate(job,json_file)
        # G=pointer.netx()
        # mapping=pointer.mapp()
        # final_result=scpy_prep_data.prepare_data(mapping,G)
        # job="m_MIDI00ID_IPE2_ExtractUnattach_JDAWS"
        return render_template("my_main.html",job=job)
    except Exception as e:
        return(e)


@app.route('/get_my_data/<job>')
def get_result(job):
    json_file=json_file_name
    pointer=intialiser.initiate(job,json_file)
    G=pointer.netx()
    mapping=pointer.mapp()
    final_result=scpy_prep_data.prepare_data(mapping,G)

    return jsonify(final_result)

@app.route('/trans_logic/', methods=['GET', 'POST'])
def procure_logic():
    # req_data={"map_name":"m_MIDI00ID_IPE2_ExtractUnattach_JDAWS","trans":"exp_CR48_EXCPTN"}
    if request.method == 'POST':
        print(request.get_json())  # parse as JSON
        req_data=request.get_json()
        # req_data=eval(ireq_data)
        # print(req_data)
        print(type(req_data))
        json_file=json_file_name
        job=req_data["map_name"]
        trans=req_data["trans"]

        pointer=intialiser.initiate(job,json_file)

        str_builder=pointer.lay_path_from(trans)
        # print(str_builder)
        str_builder=str_builder.replace('\n','<br>')
        return jsonify(str_builder)
    else:
        return "route properly"

@app.route('/detailed_logic/', methods=['GET', 'POST'])
def detailed_logic():
    # req_data={"map_name":"m_MIDI00ID_IPE2_ExtractUnattach_JDAWS","trans":"exp_CR48_EXCPTN"}
    if request.method == 'POST':
        print(request.get_json())  # parse as JSON
        req_data=request.get_json()
        # req_data=eval(ireq_data)
        # print(req_data)
        print(type(req_data))
        json_file=json_file_name
        job=req_data["map_name"]
        trans=req_data["trans"]

        pointer=intialiser.initiate(job,json_file)
        # Analyse the given transformation


        str_builder=pointer.analyse_trans(job,trans,json_file)
        print(str_builder)
        str_builder=str_builder.replace('\n','<br>')
        return jsonify(str_builder)
    else:
        return "route properly"

@app.route('/path/<job>/<src_tran>/<tgt_tran>')
def path(job,src_tran,tgt_tran):
    try:
        json_file=json_file_name
        pointer=intialiser.initiate(job,json_file)
        dummy=" "
        str_builder=pointer.col_renamed(src_tran,tgt_tran,dummy)
        # job="m_MIDI00ID_IPE2_ExtractUnattach_JDAWS"
        # str_builder=str_builder.replace('\n','<br>')
        return jsonify(str_builder)
    except Exception as e:
        return(e)

if __name__ == "__main__":
    # website_url = 'DataIntegration.ETL.DIP:5000'
    # app.config['SERVER_NAME'] = website_url
    app.run()
