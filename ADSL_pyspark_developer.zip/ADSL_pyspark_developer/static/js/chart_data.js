var getData = $.get('/build_chart_js');

getData.done(function(output) {

    var nightly_canvas = document.getElementById('bar-chart').getContext('2d');

    console.log(output[0])
    console.log(output[1])

    var dataset1 = {
        label: 'Run time',
        data: output[1],
        backgroundColor: "#48A497",
        borderColor: "#48A4D1"
    };


    var Nightly_data = {
        labels: output[0],
        datasets: [dataset1]
    };

    var nightly_Options = {
        layout: {
            padding: {
                left: 50,
                right: 50,
                top: 50,
                bottom: 50
            }
        },
        scales: {
            xAxes: [{
                barPercentage: 0.8,
                categoryPercentage: 0.6
            }],
            yAxes: [{
                ticks: {
                    min: 0
                }
            }]
        }
    };

});