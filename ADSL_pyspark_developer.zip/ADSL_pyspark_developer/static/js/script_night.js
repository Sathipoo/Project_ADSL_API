function initaial_stage() {
    fetch("/data_night").then(function(resp) {
            return resp.json();
        })
        .then(function(data) {
            result = data;
            nodes = data.node_points;
            edges = data.edge_points;
            node_details = data.node_details;

            executedata();
        })
}

function executedata() {


    // Create a new directed graph
    var g = new dagreD3.graphlib.Graph().setGraph({});



    // Automatically label each of the nodes
    nodes.forEach(function(node) {
        g.setNode(node.qs_code, { label: node.qs_code, shape: node.shape, class: [node.proto_logic_type], hovertext: node.hovertext, id: node.qs_code }); //style: 'fill: red' 
    });


    edges.forEach(function(edge) {
        g.setEdge(edge.source, edge.target, { class: [edge.status] });

    });

    var svg = d3.select("svg"),
        inner = svg.select("g");

    // Set the rankdir
    g.graph().rankdir = 'LR'; //'TB';
    g.graph().nodesep = 50;
    g.graph().ranksep = 570;
    g.graph().ranker = ['network-simplex', 'tight-tree', 'longest-path'][1];
    // g.graph().transition = (selection) => selection.transition().duration(1000);

    // Set up zoom support
    var zoom = d3.behavior.zoom().on("zoom", function() {
        inner.attr("transform", "translate(" + d3.event.translate + ")" +
            "scale(" + d3.event.scale + ")");
    });
    svg.call(zoom);
    // Create the renderer
    var render = new dagreD3.render();


    // Run the renderer. This is what draws the final graph.
    render(inner, g);


    var tooltip = d3.select("body")
        .append("div")
        .attr('id', 'tooltip_template')
        .style("position", "absolute")
        .style("background-color", "white")
        .style("border", "solid")
        .style("border-width", "2px")
        .style("border-radius", "5px")
        .style("padding", "5px")
        .style("z-index", "10")
        .style("visibility", "hidden")
        .text("Simple Tooltip...");

    var tooltip_edge = d3.select("body")
        .append("div")
        .attr('id', 'tooltip_template')
        .style("position", "absolute")
        .style("background-color", "grey")
        .style("border", "solid")
        .style("color", "white")
        .style("border-width", "2px")
        .style("border-radius", "5px")
        .style("padding", "5px")
        .style("z-index", "10")
        .style("visibility", "hidden")
        .text("Simple Tooltip...");


    inner.selectAll('g.node')
        .attr("data-hovertext", function(v) {
            return g.node(v).hovertext
        })
        .on("mouseover", function() {

            d3.select(this).style("stroke-width", "5px");
            return tooltip.style("visibility", "visible");
        })
        .on("mousemove", function() {
            tooltip.text(this.dataset.hovertext)
                .style("top", (event.pageY - 10) + "px")
                .style("left", (event.pageX + 10) + "px");
        })
        .on("mouseout", function() {
            // d3.select(this).style("stroke-width", "1px");
            return tooltip.style("visibility", "hidden");
        });


    inner.selectAll('g.edgePath')
        .attr("data-hovertext", function(a) {
            // console.log(a["v"]);
            return (a["v"])

        })
        .on("mouseover", function() { return tooltip_edge.style("visibility", "visible"); })
        .on("mousemove", function() {
            tooltip_edge.text(this.dataset.hovertext)

            .style("top", (event.pageY - 10) + "px")
                .style("left", (event.pageX + 10) + "px");
        })
        .on("mouseout", function() { return tooltip_edge.style("visibility", "hidden"); });

    // creating dependency hovers
    // ******************************************************************************************************************************
    // table display function starts here
    // ******************************************************************************************************************************


    inner.selectAll('g.node')
        .attr("data", function(v) {
            // console.log(g.node(v))
            // console.log(g.node(v))
            return g.node(v).label;
        })
        .on("click", function(d) {
            try {
                nodes.forEach(function(bnm) {
                    con = bnm["qs_code"];
                    var new_val = ('#' + con)
                    d3.select(new_val).style("stroke-width", "1px");
                });
            } catch (err) {
                console.log("hee hee")
            }
            d3.select("#tooltip_template").html(display_tooltip(d));


            fetch(`/calculate_eta/${d}`)
                .then((resp) => resp.text())
                .then(function(eta_data) {
                    result = eta_data;
                    console.log(result)
                    d3.select("#eta_pot").text(d + "  ETA : " + (result / 60).toFixedDown(2) + " mins")
                    return result
                });

            // console.log("trying to fil ets pot")

            // d3.select(this).style("stroke-width", "15px");
            // feching the radio option from the page
            var ele = document.getElementsByName('optradio')
            radio_opt_val = "one_level"; // default value
            for (i = 0; i < ele.length; i++) {
                try {
                    if (ele[i].checked) {
                        radio_opt_val = ele[i].value;
                        // console.log(ele[i].value);
                    }
                } catch (err) {
                    radio_opt_val = "one_level";
                }
            }
            // if (radio_opt_val == "one_level") {
            // i_pre = node_details[d]["pred"]
            // i_suc = node_details[d]["succ"]
            // cons = i_pre.concat(i_suc)
            //     cons = node_details[d]["one_level"]
            // } else {
            cons = node_details[d][radio_opt_val]
                // }
            console.log(radio_opt_val)
            console.log("cons are " + cons)
            try {
                cons.forEach(function(con) {
                    // console.log(con)
                    var new_val = ('#' + con);
                    d3.select(new_val).style("stroke-width", "15px");
                });

                d3.select(this).style("stroke-width", "15px");
            } catch (err) {
                console.log("faced an error: " + err);

            }
            // console.log(this.dataset.hovertext);
        })
        .on("mouseout", function(d) {
            // cons = node_details[d]["consol_touch_files"]
            // try {
            //     nodes.forEach(function(bnm) {
            //         con = bnm["qs_code"];
            //         var new_val = ('#' + con)
            //         d3.select(new_val).style("stroke-width", "1px");
            //     });
            // } catch (err) {
            //     console.log("hee hee")
            // }
            // d3.select(this).style("stroke-width", "1px");
            return tooltip.style("visibility", "hidden");
        });



    function display_tooltip(d) {
        // console.log("prede:" + node_details[d]["pred"])
        // console.log(d)

        // string_builder = ' <h2> Predecessors: ' + node_details[d]["pred"] + '</h2><h2> Successors: ' + node_details[d]["succ"] + '<h2>'

        try {

            table_builder = '<table class="table table-hover table-striped table-bordered bg-light center" id="table_tool" > <tr> <th colspan="5" class="bg-secondary"> <h4 class="text-center text-white">' + d + '</h4> </th> </tr> <tr> <th>Infa workflow</th> <th>Start time</th> <th>End time</th> <th>Status</th> <th>Avg run time</th> </tr>'

            len = Object.keys(node_details[d]["jobs"]).length;

            infa_jobs = Object.keys(node_details[d]["jobs"])

            for (i = 0; i < infa_jobs.length; i++) {
                // console.log(node_details[d]["jobs"][infa_jobs[i]])
                wf = infa_jobs[i]
                start = node_details[d]["jobs"][infa_jobs[i]]["start_time"]
                end = node_details[d]["jobs"][infa_jobs[i]]["end_time"]
                status = node_details[d]["jobs"][infa_jobs[i]]["status"]
                avg = node_details[d]["jobs"][infa_jobs[i]]["avg_time"]

                sub_tab_builder = '<tr><td>' + wf + '</td><td>' + start + '</td> <td>' + end + '</td> <td>' + status + '</td> <td>' + avg + '</td></tr>'
                table_builder = (table_builder.concat(sub_tab_builder))
            }

            preds = node_details[d]["pred"]
                // console.log(node_details[d]["pred"])
            succs = node_details[d]["succ"]
            cons = node_details[d]["consol_touch_files"]
                // console.log(cons)

            table_builder = (table_builder.concat('<th colspan="2">Predecessors</th> <th colspan="3">Successors</th> </tr> <tr> <td colspan="2">' + preds + '</td><td colspan="3">' + succs + '</td> </tr> <tr> <th>Consolidated touch files</th> <td colspan="4">' + cons + '</td> </tr> </table>'));

            // console.log(table_builder);

            return table_builder
        } catch (err) {
            data = '<table class="table table-hover table-striped table-bordered bg-light center" id="table_tool" > <tr> <th colspan="5" class="bg-secondary"> <h4 class="text-center text-white">No Record Found</h4> </th> </tr></table>'
            return (data);
        }

    }

    // Center the graph
    var initialScale = 0.07;
    zoom
        .translate([(svg.attr("width") - g.graph().width * initialScale) / 2, 100])
        .scale(initialScale)
        .event(svg);

    zoom
        .translate([(svg.attr("height") - g.graph().height * initialScale) / 2, 25])
        .scale(initialScale)
        .event(svg);


    var t2 = setTimeout(function() { initaial_stage() }, 3000000); /* setting timer */
}

function currentTime() {

    var val1 = (calcTime('Bombay', '+5.5'));

    onehalp = val1.substring(0, 11);
    twohalp = val1.substring(11, );

    document.getElementById("clock1date").innerText = onehalp + "  (IST)"; /* adding time to the div */
    document.getElementById("clock1time").innerText = twohalp;


    var val = (calcTime('Moorsevelle', '-4'));

    oneohalp = val.substring(0, 11);
    twoohalp = val.substring(11, );

    document.getElementById("clock2date").innerText = oneohalp + "  (EST)"; /* adding time to the div */
    document.getElementById("clock2time").innerText = twoohalp; /* adding time to the div */
    var t = setTimeout(function() { currentTime() }, 1000); /* setting timer */
}

function updateTime(k) {
    if (k < 10) {
        return "0" + k;
    } else {
        return k;
    }
}

currentTime(); /* calling currentTime() function to initiate the process */
initaial_stage()

function calcTime(city, offset) {

    // create Date object for current location
    d = new Date();

    // convert to msec
    // add local time zone offset
    // get UTC time in msec
    utc = d.getTime() + (d.getTimezoneOffset() * 60000);

    // create new Date object for different city
    // using supplied offset
    nd = new Date(utc + (3600000 * offset));

    // return time as a string
    dd = nd.toLocaleString('en-IN', { dateStyle: "medium" });
    tt = nd.toLocaleString('en-IN', { timeStyle: "medium" });

    //return  nd.toLocaleString('en-IN',{dateStyle:"medium",timeStyle:"medium"});
    return (dd + " " + tt)

}
Number.prototype.toFixedDown = function(digits) {
    var re = new RegExp("(\\d+\\.\\d{" + digits + "})(\\d)"),
        m = this.toString().match(re);
    return m ? parseFloat(m[1]) : this.valueOf();
};